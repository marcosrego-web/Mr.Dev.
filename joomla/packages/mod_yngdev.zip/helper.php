<?php
/**
 * @copyright	Copyright (c) 2020 Marcos Rego. All rights reserved.
 * @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
// no direct access
defined('_JEXEC') or die;
/**
 * Yng.Dev. Module
 *
 * @package		Joomla.Site
 * @subpakage	MRCategories
 */
class modYngDevHelper {
}